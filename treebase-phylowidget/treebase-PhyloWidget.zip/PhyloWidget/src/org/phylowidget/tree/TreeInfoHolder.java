package org.phylowidget.tree;

import java.io.Serializable;

/**
 * 
 * @author madhu
 * 
 * Created on February 6, 2008
 * 
 */

@Deprecated
public class TreeInfoHolder implements Serializable {

	private static final long serialVersionUID = 1L;
	private long treeId;
	private String modifiedNewickString;

	/**
	 * @return the modifiedNewickString
	 */
	public String getModifiedNewickString() {
		return modifiedNewickString;
	}

	/**
	 * @param pModifiedNewickString the modifiedNewickString to set
	 */
	public void setModifiedNewickString(String pModifiedNewickString) {
		modifiedNewickString = pModifiedNewickString;
	}

	/**
	 * @return the treeId
	 */
	public long getTreeId() {
		return treeId;
	}

	/**
	 * @param pTreeId the treeId to set
	 */
	public void setTreeId(long pTreeId) {
		treeId = pTreeId;
	}

}
